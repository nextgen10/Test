from pydantic import BaseModel
from typing import Optional

class Prompt(BaseModel):
    prompt: Optional[str]