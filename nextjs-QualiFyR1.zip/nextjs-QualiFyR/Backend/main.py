from fastapi import FastAPI, Response, Cookie, Request, File, UploadFile
import os, json
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
from openai import AzureOpenAI
from prompthandling import *
from langchain.prompts import PromptTemplate, ChatPromptTemplate
from langchain.chains import LLMChain, SimpleSequentialChain
from langchain_openai import AzureChatOpenAI
from dotenv import load_dotenv
from schemas.Prompt import Prompt
from typing import List
import docx
from langchain_community.document_loaders import UnstructuredWordDocumentLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
import docx2txt
import re

# Loan environment Variables
load_dotenv()

app = FastAPI(
    title="Test",
    description="Test",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins = ["*"],
    allow_credentials =True,
    allow_methods=["*"],
    allow_headers=["*"]
)
llm = AzureChatOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    openai_api_version=os.getenv("OPENAI_API_VERSION"),
    azure_deployment=os.getenv("GPT_DEPLOYMENT_NAME"),
    temperature=0
)

client = AzureOpenAI(
    api_key = os.getenv("AZURE_OPENAI_API_KEY"),
    api_version = os.getenv("OPENAI_API_VERSION"),
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
)

def doc_files(uploaded_files):
    docx_text = ""
    doc = docx.Document(uploaded_files)
    for para in doc.paragraphs:
        docx_text += para.text + "\n"
    return docx_text
    # loader = UnstructuredWordDocumentLoader(uploaded_files, mode='elements', strategy='fast') 
    # docs = loader.load()
    # text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    # splits = text_splitter.split_documents(docs)
    # print(docs)
    # return splits

def wordDocFilesLoad(uploaded_files):
    # loader = UnstructuredWordDocumentLoader(uploaded_files, mode='elements', strategy='fast') 
    # docs = loader.load()
    # # text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    # # splits = text_splitter.split_documents(docs)
    # print(docs)
    # return docs
    doc = docx2txt.process(uploaded_files)
    doc = re.sub(r'\n\s*\n', '\n', doc, flags=re.MULTILINE)
    print(doc)
    return doc
    
def prompting(story_input):
    print ("------- Prompt Begin -------")
    # Create a LangChain prompt template that we can insert values to later
    prompt_template = PromptTemplate(
        input_variables=["user_story"],
        template=template_story,
    )
    # confusing_text="Testing"
    final_prompt = prompt_template.format(user_story=story_input)
    print(final_prompt)
    print ("------- Prompt End -------")
    chain = LLMChain(llm=llm, prompt=prompt_template)
    return chain

def qualityCheck(promptStory):
    # promptStory = promptStory.model_dump_json()
    if not promptStory:
        return {"message": "No prompt given"}

    story_chain = prompting(promptStory)
    
    overall_chain = SimpleSequentialChain(chains=[story_chain], verbose=True)
    qualityCheckScore = overall_chain.run("")
    return qualityCheckScore

def scoreUserStory(story_text):
    prompt_template1 = PromptTemplate(input_variables=["story1"], template=template1)
    story_chain1 = LLMChain(llm=llm, prompt=prompt_template1)
    prompt_template2 = PromptTemplate(input_variables=["story2"], template=template2)
    story_chain2 = LLMChain(llm=llm, prompt=prompt_template2)
    # prompt_template3 = PromptTemplate(input_variables=["json_output"], template=template3)
    # json_chain = LLMChain(llm=llm, prompt=prompt_template3)
    # This is the overall chain where we run these two chains in sequence.
    overall_chain = SimpleSequentialChain(chains=[story_chain1, story_chain2], verbose=True)
    score = overall_chain.invoke(story_text)
    return score

@app.post("/chat_new")
async def chat(prompt: Prompt):
    prompt = prompt.model_dump_json()
    if not prompt:
        return {"message": "No prompt given"}

    story_chain = prompting(prompt)
    
    overall_chain = SimpleSequentialChain(chains=[story_chain], verbose=True)
    qualityCheck = overall_chain.run("")
    return qualityCheck

@app.post("/chat")
async def chat(prompt: Prompt):
    prompt = prompt.model_dump_json()
    if not prompt:
        return {"message": "No prompt given"}
    
    response = client.chat.completions.create(
        model=os.getenv("deployment_name"),
        messages=[{'role': 'system', 'content': prompt}]
    )
    response = response.model_dump_json(indent=2)
    response = json.loads(response)

    response = response['choices'][0]['message']['content']
    return response

@app.get("/")
def health_check():
    return {"status":"ok"}

@app.get("/health")
def health_check():
    return {"status":"ok"}

@app.post("/upload")
async def upload(files: List[UploadFile] = File(...)):
    for file in files:
        if not os.path.exists("uploaded_files"):
            os.makedirs("uploaded_files")
        if os.path.exists(f'uploaded_files/{file.filename}'):
            return {"message": f"File already exists: {file.filename}"}
        else:
            try:
                contents = file.file.read()
                with open(f'uploaded_files/{file.filename}', 'wb') as f:
                    f.write(contents)
            except Exception:
                return {"message": "There was an error uploading the file(s)"}
            finally:
                file.file.close()
                doc_text = wordDocFilesLoad(f'uploaded_files/{file.filename}')
                qualityCheckScore = scoreUserStory(doc_text)
    return qualityCheckScore

    return {"message": f"Successfuly uploaded {[file.filename for file in files]}"}
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8443)
