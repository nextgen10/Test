# Create our template
template3 = """
%ACTION
Validate the JSON provided and check if it is a valid JSON object. If it is not a valid JSON object, then correct it.

%JSON
{json_output}

%OUTPUT_FORMAT: Single JSON object with no additional characters or explanation.
"""
template2 = """
%ACTION
Evaluate the User Story for quality based on the context provided and score them from 1 to 10 where 10 is the highest quality. 
If any of the quality check is missing then give a score as zero.

%CONTEXT:
Evaluate user stories for below mentioned characteristics.

1. User-Centered
2. Independent
3. Negotiable
4. Valuable
5. Estimable
6. Small
7. Testable
8. Acceptance Criteria
9. Prioritized
10. Collaboration and Understanding

Use below user stories as reference for scoring:
%REFERENCE USER STORY1: The user story is highest quality and rated 10 for each quality parameter mentioned.
Title: Online payment option for utility bills 
Description: As a registered user, I want to be able to pay all my utility bills (such as water, electricity, and gas) online so that I can avoid the hassle of manual payment methods and keep track of my previous payments. 
Acceptance Criteria: 
1. The user should be able to view all utility bills the moment they log in. 
2. The user should be able to select any of utility bills listed and see the detailed bill. 
3. The system should provide the option for online payment for the selected bill. 
4. Once the payment is successful, the system should update the bill status and provide the user with a receipt. 
5. The user should be allowed to download and save the receipt for their records. 
6. The user should be able to view his payment history.



%USER_STORY:
{story2}

%RULES:
1. Provide reason only if score is less than 10 otherwise say N/A
2. Provide Recommendations only if score is less than 10 otherwise say N/A
3. Score should be between 0 to 10
4. If score < 6 and score > 0 then consider it as score 5
5. If score < 8 and score > 5 then consider it as score 7
6. If there is no data available for any category then score should be 0 and provide reason and recommendation.


%OUTPUT_JSON_FORMAT:
  [
    {{"Category": "User-Centered", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Independent", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Negotiable", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Valuable", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Estimable", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Small", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Testable", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Acceptance Criteria", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Prioritized", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Collaboration and Understanding", "Score": "", "Reason": "", "Recommendations": ""}},
  ]

"""

template1 = """
%ACTION:
Given the user story, your job is to reformat and rewrite the user story in a more readable format. Include only Story Title, Description and Acceptance Criteria.

%RULES:
1. Do not loose write Title, Description or Acceptance Criteria on your own. If any of this section is missing then say "Missing Information".
2. Do not make up any section or answer on your owen.
User Story: {story1}
"""

test = """
Single Json object for all points with no additional characters. The output should be only json object with output parameters as Category, Score, Reason and Recommendations.
Can you make the user story more readable? Do not loose any important data or terms from the context.
{{
  "DATA":  [
    {{"Category": "User-Centered", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Independent", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Negotiable", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Valuable", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Estimable", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Small", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Testable", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Acceptance Criteria", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Prioritized", "Score": "", "Reason": "", "Recommendations": ""}},
    {{"Category": "Collaboration and Understanding", "Score": "", "Reason": "", "Recommendations": ""}},
  ]
}}
"""