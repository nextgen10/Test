'use client'
import ThemeToggle from './ThemeToggle';
import { SiOpenaigym } from 'react-icons/si';
import { Typography } from '@material-ui/core';
import { Divider } from '@material-ui/core';

const SidebarHeader = () => {
  return (
    <div>
      <div className="flex items-center mb-4 gap-4 px-4">
        <SiOpenaigym className="w-10 h-10"/>
        <Typography variant="h5" style={{ fontFamily: 'cursive' }} className="mr-auto">
          STORY SENSE
        </Typography>
        
        {/* <ThemeToggle /> */}
      </div>
      <Typography variant="body2" component="p" align='right' color='secondary'>
          (Gen-AI)
        </Typography>
      <Divider style={{ backgroundColor: 'grey', height: '2px' }}/>
    </div>
  );
};
export default SidebarHeader;


