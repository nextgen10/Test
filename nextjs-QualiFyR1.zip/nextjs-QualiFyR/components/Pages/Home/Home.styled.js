import styled from "styled-components";



export const Background = styled.video`
    width: 100%;
    height: 100%;
    object-fit: cover;
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    z-index: -1;
    -webkit-transform: rotateY(180deg);
`

export const FlexCenter = styled.section`
    width: 65vw;
    display: flex;
    padding: 100px 40px;
    flex-direction: column;
    justify-content: flex-start;
    align-items: flex-start;
    gap: 20px;

    h1{
        font-size: 32px;
        span{
            font-size: 42px;

        }
    }

    h2{
        font-size: 20px;
    }

    h1,h2{
        color: #ffffff;
    }
`