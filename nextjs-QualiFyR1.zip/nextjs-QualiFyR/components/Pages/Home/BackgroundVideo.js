const BackgroundVideo = () => {
    return ( 
        <>
            <Background autoPlay="autoplay" loop="loop" muted>
                <source src="" type="video/mp4"/>
                Your browser does not support the video tag
            </Background>
        </>
     );
}
 
export default BackgroundVideo;
