'use client';

import { useState } from 'react';
import { Typography } from '@material-ui/core';

const Chat = () => {
  const [text, setText] = useState('');
  const [messages, setMessages] = useState([]);
  const [isPending, setIsPending] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
  
    setIsPending(true);
    const prompt = `${text}`;
    console.log(prompt)
    const response = await fetch('http://localhost:8000/chat/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({prompt}),
    });
  
    const data = await response.json();
    console.log(data)
    setMessages(prevMessages => [...prevMessages, { role: 'user', content: text }, { role: 'bot', content: data }]);
    console.log(...messages)
    setText('');
  
    setIsPending(false);
  };

  return (
    <div className="min-h-[calc(100vh-6rem)] grid grid-rows-[1fr,auto]">
    <Typography className='select-none' variant="h5" align="left" gutterBottom color="primary">Hello! I am your AI Assistant, How can i help you?</Typography>
      <div>
        {messages.map(({ role, content }, index) => {
          const avatar = role == 'user' ? '👤' : '🤖';
          const bcg = role === 'user' ? 'bg-base-200' : 'bg-base-100';
          return (
            <div
              key={index}
              className={`${bcg} flex py-6 -mx-8 px-8 text-xl leading-loose border-b border-base-300`}
            >
              <span className="mr-4">{avatar}</span>
              <p className="max-w-3xl">{content}</p>
            </div>
          );
        })}
        {isPending ? <span className="loading"></span> : null}
      </div>
      <form onSubmit={handleSubmit} className="max-w-4xl pt-12">
        <div className="join w-full">
          <input
            type="text"
            placeholder="Ask me somthing..."
            className="input input-bordered join-item w-full"
            value={text}
            required
            onChange={e => setText(e.target.value)}
          />
          <button
            className="btn btn-primary join-item"
            type="submit"
            disabled={isPending}
          >
            {isPending ? 'please wait...' : 'Send'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default Chat;