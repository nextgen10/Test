'use client';
import { List, ListItem, ListItemIcon, ListItemText } from '@material-ui/core';
import { Dashboard as DashboardIcon, Chat as ChatIcon, CheckCircle as CheckCircleIcon, Person as PersonIcon } from '@material-ui/icons';
import Link from 'next/link';
import { Box } from '@material-ui/core';
import InfoIcon from '@mui/icons-material/Info';



const links = [
  { 
    href: '/about', 
    label: 'About',
    icon: <InfoIcon style={{ color: 'grey' }}/>
  },
  { 
    href: '/chat', 
    label: 'AI Assistant',
    icon: <ChatIcon style={{ color: 'grey' }}/>
  },
  { 
    href: '/qcheck', 
    label: 'Quality Check',
    icon: <CheckCircleIcon style={{ color: 'grey' }}/>
  }
  // ,
  // { 
  //   href: '/profile', 
  //   label: 'Profile',
  //   icon: <PersonIcon style={{ color: 'grey' }}/>
  // }
];

const NavLinks = () => {
  return (
    <Box display="flex" flexDirection="column" height="100%">
      <List>
        {links.map((link) => (
          <ListItem button key={link.href}>
            <ListItemIcon>
              {link.icon}
            </ListItemIcon>
            <Link href={link.href}>
              <ListItemText primary={link.label} />
            </Link>
          </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default NavLinks;