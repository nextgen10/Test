import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

let db;

const initializeDatabase = async () => {
  db = await open({
    filename: './mydatabase.db',
    driver: sqlite3.Database
  });
};

const getDb = () => {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase first.');
  }
  return db;
};

export { initializeDatabase, getDb };