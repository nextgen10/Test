'use server';
const { OpenAIClient, AzureKeyCredential } = require("@azure/openai");
require("dotenv").config();

const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
const apiKey = process.env.AZURE_OPENAI_API_KEY;

const client = new OpenAIClient(endpoint, new AzureKeyCredential(apiKey));
const deploymentName = process.env.DEPLOYMENT_NAME;

export const generateTestCasesForWorkflow = async chatMessages => {
  try {

    // Call your FastAPI backend
    const response = await fetch('http://localhost:8000/chat/', { 
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ userStory })  
    });

    if (!response.ok) {
      throw new Error('Error fetching test cases');
    } 
    
    const generatedTestCases = await response.text();
    console.log(generatedTestCases)
    return generatedTestCases

  } catch (error) {
    console.error(`Error`); 
  } 
};

export const generateChatResponse = async query => {
  //in order to add context we will be passing in an array.
  try {
    const response = await fetch('http://localhost:8000/chat/', { 
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ query })  
    });
    return response.choices[0].message; //this is the object provided my OpenAI
  } catch (error) {
    console.log(error)
    //);
    return null;
  }
};

export const generateTourResponse = async ({ city, country }) => {
  // prompt
  const query = `Find a exact ${city} in this exact ${country}.
If ${city} and ${country} exist, create a list of things families can do in this ${city},${country}. 
Once you have a list, create a one-day tour. Response should be  in the following JSON format: 
{
  "tour": {
    "city": "${city}",
    "country": "${country}",
    "title": "title of the tour",
    "description": "short description of the city and tour",
    "stops": ["short paragraph on the stop 1 ", "short paragraph on the stop 2","short paragraph on the stop 3"]
  }
}
"stops" property should include only three stops.
If you can't find info on exact ${city}, or ${city} does not exist, or it's population is less than 1, or it is not located in the following ${country},   return { "tour": null }, with no additional characters.`;

  try {
    const response = await openai.chat.completions.create({
      messages: [
        { role: 'system', content: 'you are a tour guid' },
        { role: 'user', content: query }
      ],
      model: 'gpt-3.5-turbo',
      temperature: 0
    });
    const tourData = JSON.parse(response.choices[0].message.content);
    if (!tourData.tour) {
      return null;
    }
    return tourData.tour;
  } catch (error) {
    console.log(error);
    return null;
  }
};

// database
export const getExistingTour = async ({ city, country }) => {
  return prisma.tour.findUnique({
    where: {
      city_country: {
        city,
        country
      }
    }
  });
};

export const createNewTour = async tour => {
  return prisma.tour.create({
    data: tour
  });
};

export const getAllTours = async searchTerm => {
  if (!searchTerm) {
    const tours = await prisma.tour.findMany({
      orderBy: {
        city: 'asc'
      }
    });
    return tours;
  }
  const tours = await prisma.tour.findMany({
    where: {
      OR: [
        {
          city: {
            contains: searchTerm
          }
        },
        {
          country: {
            contains: searchTerm
          }
        }
      ]
    },
    orderBy: {
      city: 'asc'
    }
  });
  return tours;
};

export const getSingleTour = async id => {
  return prisma.tour.findUnique({
    where: {
      id
    }
  });
};

export const generateTourImage = async ({ city, country }) => {
  try {
    const tourImage = await openai.images.generate({
      prompt: `a panoramic view of the ${city} ${country}`,
      n: 1,
      size: '512x512'
    });
    return tourImage?.data[0]?.url;
  } catch (error) {
    return null;
  }
};
