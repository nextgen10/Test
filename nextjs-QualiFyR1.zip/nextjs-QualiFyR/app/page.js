"use client"
import Link from 'next/link';
import { FlexCenter } from "../components/Pages/Home/Home.styled";
import BackgroundPatterns from "../components/Global Components/BackgroundPatterns";

const HomePage = () => {
  return (
    <>    
    <BackgroundPatterns />
    <div className="hero min-h-screen bg-base-300">
      <div className="hero-content text-center">
        <div className="max-w-md">
          <h1 className="text-6xl font-bold select-none text-primary" style={{ fontFamily: 'cursive' }}>STORY SENSE</h1>
          <p className="py-6 text-lg leading-loose text-white select-none">
            AI companion. Powered by OpenAI, it
            validates your User Story for Quality Check
          </p>
          <Link href="/about" className="btn btn-primary ">
            Get Started
          </Link>
        </div>
      </div>
    </div>

        </>
  );
};
export default HomePage;
