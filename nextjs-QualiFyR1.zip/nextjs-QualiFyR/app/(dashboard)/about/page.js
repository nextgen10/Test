'use client'
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Container, Typography, Grid, Paper } from '@material-ui/core';

const useStyles = makeStyles((theme) => ({
    root: {
        marginTop: theme.spacing(4),
    },
    section: {
        height: '100vh',
    },
}));
const AboutPage = () => {
    const classes = useStyles();

    return (
        <Container className={classes.root}>
            <Typography className='select-none' variant="h5" component="h1" gutterBottom color="inherit">
                About
            </Typography>

            <Grid container spacing={4}>
                <Grid item xs={12} sm={6}>
                    <Paper class="p-10 bg-base-300 rounded-badge" data-theme="dark">
                        <Typography className='select-none' variant="h5" component="h2" gutterBottom color="primary">
                            Guidelines
                        </Typography>
                        <Typography variant="body1" component="p">
                            Add your sample story content here...
                        </Typography>

                    </Paper>
                </Grid>

                <Grid item xs={12} sm={6}>
                    <Paper class="p-10 bg-base-300 rounded-badge" data-theme="dark">
                        <Typography className='select-none' variant="h6" component="h2" gutterBottom color="primary">
                            Good Quality Story Sample
                        </Typography>
                        <Typography variant="body1" component="p">
                            Add your sample story content here...
                        </Typography>
                    </Paper>
                </Grid>
            </Grid>
        </Container>
    );
};

export default AboutPage;