'use client';
import React, { useState } from 'react';
import { Card, CardContent, Button, Typography, Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { LinearProgress } from '@material-ui/core';
import { Divider } from '@material-ui/core';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import CircularProgress from '@material-ui/core/CircularProgress';


const useStyles = makeStyles({
  tableContainer: {
    maxHeight: 'calc(90vh - 200px)', // Adjust as needed
    overflow: 'auto',
    backgroundColor: 'inherit',
    borderRadius: '5px',
    border: '0.1px solid #9c9c9c',
  },

  card: {
    marginBottom: '20px',
    backgroundColor: 'inherit',
    textAlign: 'center',
    borderRadius: '100px',
    border: '2px solid #9c9c9c',
    userSelect: 'none',
  },

  button: {
    marginTop: '10px',
    marginBottom: '10px',
    '&:hover': {
      backgroundColor: '#9c9c9c',
      color: 'white',
    },    
  },
  tableHeader: {
    fontWeight: 'bold',
    backgroundColor: '#9c9c9c', // Adjust as needed
  },

  column1: {
    width: '18%', // adjust as needed
  },
  column2: {
    width: '12%', // adjust as needed
  },
  column3: {
    width: '35%', // adjust as needed
  },
  column4: {
    width: '35%', // adjust as needed
  },
  tableCell: {
    backgroundColor: 'inherit',
  },
});

const QualityCheck = () => {
  const classes = useStyles();
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState([
    {"Category": "User-Centered", "Score": "", "Reason": "", "Recommendations": ""},
    {"Category": "Independent", "Score": "", "Reason": "", "Recommendations": ""},
    {"Category": "Negotiable", "Score": "", "Reason": "", "Recommendations": ""},
    {"Category": "Valuable", "Score": "", "Reason": "", "Recommendations": ""},
    {"Category": "Estimable", "Score": "", "Reason": "", "Recommendations": ""},
    {"Category": "Small", "Score": "", "Reason": "", "Recommendations": ""},
    {"Category": "Testable", "Score": "", "Reason": "", "Recommendations": ""},
    {"Category": "Acceptance Criteria", "Score": "", "Reason": "", "Recommendations": ""},
    {"Category": "Prioritized", "Score": "", "Reason": "", "Recommendations": ""},
    {"Category": "Collaboration and Understanding", "Score": "", "Reason": "", "Recommendations": ""},
  ]

);

  const uploadFile = async (event) => {
    setIsLoading(true);
    const files = event.target.files;
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    try {
      const response = await fetch('http://localhost:8000/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      } else {
          const jsonData = await response.json();
          if (jsonData.message && jsonData.message.includes('File already exists')) {
            toast.error(jsonData.message);
          } else {
            setData(JSON.parse(jsonData.output));
            toast.success('Quality score calculated successfully');
          }
        }
    } catch (error) {
      console.error('File upload failed', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Add this function inside your component
  const calculateAverageScore = () => {
    const totalScore = data.reduce((total, item) => total + (Number(item.Score) || 0), 0);
    return (totalScore / data.length) || 0;
  };
  return (
    <Box>
      <ToastContainer />
      <Typography variant="h5" className='select-none'>Quality Check</Typography>
      {isLoading ? (
      <CircularProgress />
      ) : (
        <>
          <input
            accept=".docx"
            style={{ display: 'none' }}
            id="raised-button-file"
            type="file"
            multiple
            onChange={uploadFile}
            disabled={isLoading}
          />
          <label htmlFor="raised-button-file">
            <Button variant="outlined" color="inherit" component="span" className={classes.button} disabled={isLoading}>
              Upload
            </Button>
          </label>
        </>
      )}
      {/* <Divider /> */}
      <Card className={classes.card}>
        <CardContent>
          <Typography variant="h4" style={{ fontFamily: 'unset', color: 'green' }} className="mr-auto">
            User Story Quality Score: (~) { }
            {calculateAverageScore()}
          </Typography>
        </CardContent>
      </Card>
      {/* <Divider /> */}
      {data && (
        <TableContainer component={Paper} className={classes.tableContainer}>
        <Table aria-label="simple table">
            <TableHead>
            <TableRow>
              <TableCell className={`${classes.tableHeader} ${classes.column1}`}>Category</TableCell>
              <TableCell className={`${classes.tableHeader} ${classes.column2}`}>Score (1-10)</TableCell>
              <TableCell className={`${classes.tableHeader} ${classes.column3}`}>Reason</TableCell>
              <TableCell className={`${classes.tableHeader} ${classes.column4}`}>Recommendations</TableCell>
            </TableRow>
            </TableHead>
            <TableBody>
            {data.map((value, index) => (
                <TableRow key={index}>
                  <TableCell style={{ color: 'grey' }}>{value.Category || '-'}</TableCell>
                  <TableCell style={{ color: 'grey' }}>
                    {value.Score || '-'}
                    <LinearProgress variant="determinate" value={Number(value.Score) * 10} />
                  </TableCell>
                  <TableCell style={{ color: 'grey' }}>{value.Reason || '-'}</TableCell>
                  <TableCell style={{ color: 'grey' }}>{value.Recommendations || '-'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
};

export default QualityCheck;