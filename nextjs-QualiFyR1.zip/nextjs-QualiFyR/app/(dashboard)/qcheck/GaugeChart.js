import { useEffect, useRef } from 'react';
import * as d3 from 'd3';

const GaugeChart = ({ score }) => {
  const ref = useRef();

  useEffect(() => {
    const svg = d3.select(ref.current)
      .attr('width', 400)
      .attr('height', 100);

    const x = d3.scaleLinear()
      .domain([1, 10])
      .range([0, 400]);

    svg.append('rect')
      .attr('width', x(score))
      .attr('height', 10)
      .attr('fill', score <= 3 ? 'red' : score <= 7 ? 'yellow' : 'green');

    svg.append('polygon')
      .attr('points', `${x(score)},0 ${x(score) - 10},20 ${x(score) + 10},20`)
      .attr('fill', 'black');
  }, [score]);

  return <svg ref={ref} />;
};

export default GaugeChart;