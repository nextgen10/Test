import { UserProfile } from '@clerk/nextjs';

const ProfilePage = () => {
  return <UserProfile />;
};
export default ProfilePage;
