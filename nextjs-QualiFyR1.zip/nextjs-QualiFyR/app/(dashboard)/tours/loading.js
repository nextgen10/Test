const loading = () => {
  return <span className="loading loading-lg">loading</span>;
};
export default loading;
